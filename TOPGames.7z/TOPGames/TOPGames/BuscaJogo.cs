﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace TOPGames
{
    class BuscaJogo
    {
        public int ID { get; set; }
        public string Situação { get; set; }
        public DateTime Data_Pedido { get; set; }

        public List<BuscaJogo> listabuscajogo()
        {
            List<BuscaJogo> li = new List<BuscaJogo>();
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM PedidoJogo";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                BuscaJogo u = new BuscaJogo();
                u.ID = (int)dr["Id"];
                u.Situação = dr["situacao"].ToString();
                u.Data_Pedido = Convert.ToDateTime(dr["data_pedido"]);
                li.Add(u);
            }
            return li;
        }
    }
}
