﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TOPGames
{
    public partial class FormAluguel : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\TOPGames\\TOPGames\\DB.mdf;Integrated Security=True");
        public FormAluguel()
        {
            InitializeComponent();
        }
        public void CarregaCbxCliente()
        {
            string cli = "SELECT * FROM Cliente ORDER BY nome";
            SqlCommand cmd = new SqlCommand(cli, con);
            con.Open();
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(cli, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "Cliente");
            cbxCliente.ValueMember = "id";
            cbxCliente.DisplayMember = "nome";
            cbxCliente.DataSource = ds.Tables["Cliente"];
            con.Close();
        }

        public void CarregaCbxJogo()
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            string pro = "SELECT * FROM Jogo ORDER BY nome";
            SqlCommand cmd = new SqlCommand(pro, con);
            con.Open();
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(pro, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "Jogo");
            cbxJogo.ValueMember = "id";
            cbxJogo.DisplayMember = "nome";
            cbxJogo.DataSource = ds.Tables["Jogo"];
            con.Close();
        }

        private void FormAluguel_Load(object sender, EventArgs e)
        {
            if (cbxCliente.DisplayMember == "")
            {
                cbxJogo.Enabled = false;
                txtIdJogo.Enabled = false;
                txtQuantidade.Enabled = false;
                txtPreco.Enabled = false;
                dgvVenda.Enabled = true;
                dgvId.Enabled = false;
                btnAdicionarJogo.Enabled = false;
                btnAtualizarJogo.Enabled = false;
                btnExcluirJogo.Enabled = false;
                txtTotalGeral.Enabled = false;
                btnLocar.Enabled = false;
                btnNovaLocacao.Enabled = true;
                btnFinalizarLocacao.Enabled = false;
                btnAtualizarLocacao.Enabled = false;

            }
            CarregaCbxCliente();
            BuscaJogo ped = new BuscaJogo();
            List<BuscaJogo> pedidos = ped.listabuscajogo();
            dgvId.DataSource = pedidos;
        }

        private void btnNovoPedido_Click(object sender, EventArgs e)
        {
            cbxJogo.Enabled = true;
            CarregaCbxJogo();
            txtIdJogo.Enabled = true;
            txtQuantidade.Enabled = true;
            txtPreco.Enabled = true;
            dgvVenda.Enabled = true;
            dgvId.Enabled = true;
            btnAdicionarJogo.Enabled = true;
            btnAtualizarJogo.Enabled = true;
            btnExcluirJogo.Enabled = true;
            txtTotalGeral.Enabled = true;
            btnLocar.Enabled = true;
            btnNovaLocacao.Enabled = true;
            btnFinalizarLocacao.Enabled = true;
            btnAtualizarLocacao.Enabled = true;
            dgvVenda.Columns.Add("ID", "ID");
            dgvVenda.Columns.Add("Jogo", "Jogo");
            dgvVenda.Columns.Add("Quantidade", "Quantidade");
            dgvVenda.Columns.Add("Valor", "Valor");
            dgvVenda.Columns.Add("Total", "Total");
        }

        private void cbxJogo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            SqlCommand cmd = new SqlCommand("SELECT * FROM Jogo WHERE Id=@Id", con);
            cmd.Parameters.AddWithValue("@Id", cbxJogo.SelectedValue);
            cmd.CommandType = CommandType.Text;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                txtPreco.Text = dr["valor"].ToString();
                txtIdJogo.Text = dr["Id"].ToString();
                txtQuantidade.Focus();
                dr.Close();
                con.Close();
            }
        }

        private void btnAdicionarJogo_Click(object sender, EventArgs e)
        {
            var repetido = false;
            foreach (DataGridViewRow dr in dgvVenda.Rows)
            {
                if (txtIdJogo.Text == Convert.ToString(dr.Cells[0].Value))
                {
                    repetido = true;
                }
            }
            if (repetido == false)
            {
                DataGridViewRow item = new DataGridViewRow();
                item.CreateCells(dgvVenda);
                item.Cells[0].Value = txtIdJogo.Text;
                item.Cells[1].Value = cbxJogo.Text;
                item.Cells[2].Value = txtQuantidade.Text;
                item.Cells[3].Value = txtPreco.Text;
                item.Cells[4].Value = Convert.ToDecimal(txtPreco.Text) * Convert.ToDecimal(txtQuantidade.Text);
                dgvVenda.Rows.Add(item);
                cbxJogo.Text = "";
                txtIdJogo.Text = "";
                txtQuantidade.Text = "";
                txtPreco.Text = "";
                decimal soma = 0;
                foreach (DataGridViewRow dr in dgvVenda.Rows)
                    soma += Convert.ToDecimal(dr.Cells[4].Value);
                txtTotalGeral.Text = Convert.ToString(soma);
            }
            else
            {
                MessageBox.Show("Item já consta na lista de pedido!", "Item Repetido", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvVenda_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = this.dgvVenda.Rows[e.RowIndex];
            cbxJogo.Text = row.Cells[1].Value.ToString();
            txtIdJogo.Text = row.Cells[0].Value.ToString();
            txtQuantidade.Text = row.Cells[2].Value.ToString();
            txtPreco.Text = row.Cells[3].Value.ToString();
        }

        private void btnAtualizarJogo_Click(object sender, EventArgs e)
        {
            int linha = dgvVenda.CurrentRow.Index;
            dgvVenda.Rows[linha].Cells[0].Value = txtIdJogo.Text;
            dgvVenda.Rows[linha].Cells[1].Value = cbxJogo.Text;
            dgvVenda.Rows[linha].Cells[2].Value = txtQuantidade.Text;
            dgvVenda.Rows[linha].Cells[3].Value = txtPreco.Text;
            dgvVenda.Rows[linha].Cells[4].Value = Convert.ToDecimal(txtPreco.Text) * Convert.ToDecimal(txtQuantidade.Text);

            cbxJogo.Text = "";
            txtIdJogo.Text = "";
            txtQuantidade.Text = "";
            txtPreco.Text = "";
            decimal soma = 0;
            foreach (DataGridViewRow dr in dgvVenda.Rows)
                soma += Convert.ToDecimal(dr.Cells[4].Value);
            txtTotalGeral.Text = Convert.ToString(soma);
        }

        private void btnExcluirJogo_Click(object sender, EventArgs e)
        {
            int linha = dgvVenda.CurrentRow.Index;
            dgvVenda.Rows.RemoveAt(linha);
            dgvVenda.Refresh();
            cbxJogo.Text = "";
            txtIdJogo.Text = "";
            txtQuantidade.Text = "";
            txtPreco.Text = "";
            decimal soma = 0;
            foreach (DataGridViewRow dr in dgvVenda.Rows)
                soma += Convert.ToDecimal(dr.Cells[4].Value);
            txtTotalGeral.Text = Convert.ToString(soma);
        }

        private void txtQuantidade_Leave(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("Quantidade_Jogo", con);
            cmd.Parameters.AddWithValue("@Id", txtIdJogo.Text);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader rd = cmd.ExecuteReader();
            int valor1 = 0;
            bool conversaoSucedida = int.TryParse(txtQuantidade.Text, out valor1);
            if (rd.Read())
            {
                int valor2 = Convert.ToInt32(rd["quantidade"].ToString());
                if (valor1 > valor2)
                {
                    MessageBox.Show("Não tem quantidade suficiente em estoque!", "Estoque Insuficiente", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtQuantidade.Text = "";
                    txtQuantidade.Focus();
                    con.Close();
                }
            }
        }

        private void btnFinalizarPedido_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("InserirPedidoJogo", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id_cliente", SqlDbType.NChar).Value = cbxCliente.SelectedValue;
            cmd.Parameters.AddWithValue("@valor_total", SqlDbType.Decimal).Value = Convert.ToDecimal(txtTotalGeral.Text);
            cmd.Parameters.AddWithValue("@data_pedido", SqlDbType.Date).Value = DateTime.Now.Date;
            cmd.Parameters.AddWithValue("@situacao", SqlDbType.NChar).Value = "Aberta";
            cmd.ExecuteNonQuery();
            string idpedido = "SELECT IDENT_CURRENT('PedidoJogo') AS Id";
            SqlCommand cmdpedido = new SqlCommand(idpedido, con);
            Int32 idpedido2 = Convert.ToInt32(cmdpedido.ExecuteScalar());
            foreach (DataGridViewRow dr in dgvVenda.Rows)
            {
                SqlCommand cmditens = new SqlCommand("ItensPedidosJogo", con);
                cmditens.CommandType = CommandType.StoredProcedure;
                cmditens.Parameters.AddWithValue("@id_pedido", SqlDbType.Int).Value = idpedido2;
                cmditens.Parameters.AddWithValue("@id_jogo", SqlDbType.Int).Value = Convert.ToInt32(dr.Cells[0].Value);
                cmditens.Parameters.AddWithValue("@quantidade", SqlDbType.Int).Value = Convert.ToInt32(dr.Cells[2].Value);
                cmditens.Parameters.AddWithValue("@preco", SqlDbType.Decimal).Value = Convert.ToDecimal(dr.Cells[3].Value);
                cmditens.Parameters.AddWithValue("@total", SqlDbType.Decimal).Value = Convert.ToDecimal(dr.Cells[4].Value);
                cmditens.ExecuteNonQuery();
            }
            con.Close();
            dgvVenda.Rows.Clear();
            dgvVenda.Refresh();
            txtTotalGeral.Text = "";
            MessageBox.Show("Pedido realizado com sucesso!", "Pedido", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            CarregaCbxJogo();
            txtTotalGeral.Text = "";
            dgvVenda.Columns.Clear();
            dgvVenda.Rows.Clear();
            con.Open();
            SqlCommand cmd = new SqlCommand("LocalizarPedidoJogo", con);
            cmd.Parameters.AddWithValue("@Id", SqlDbType.Int).Value = Convert.ToInt32(txtLocacao.Text.Trim());
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            int linhas = dt.Rows.Count;
            if (dt.Rows.Count > 0)
            {
                cbxCliente.Enabled = true;
                cbxCliente.Text = "";
                cbxCliente.Text = dt.Rows[0]["nomecliente"].ToString();
                txtTotalGeral.Text = dt.Rows[0]["valor_total"].ToString();
                cbxJogo.Enabled = true;
                txtIdJogo.Enabled = true;
                txtQuantidade.Enabled = true;
                txtPreco.Enabled = true;
                dgvVenda.Enabled = true;
                btnAdicionarJogo.Enabled = true;
                btnAtualizarJogo.Enabled = true;
                btnExcluirJogo.Enabled = true;
                txtTotalGeral.Enabled = true;
                btnLocar.Enabled = true;
                btnNovaLocacao.Enabled = true;
                btnFinalizarLocacao.Enabled = true;
                btnAtualizarJogo.Enabled = true;
                dgvVenda.Columns.Add("ID", "ID");
                dgvVenda.Columns.Add("Jogo", "Jogo");
                dgvVenda.Columns.Add("Quantidade", "Quantidade");
                dgvVenda.Columns.Add("Valor", "Valor");
                dgvVenda.Columns.Add("Total", "Total");
                for (int i = 0; i < linhas; i++)
                {
                    DataGridViewRow item = new DataGridViewRow();
                    item.CreateCells(dgvVenda);
                    item.Cells[0].Value = dt.Rows[i]["id_jogo"].ToString();
                    item.Cells[1].Value = dt.Rows[i]["nomejogo"].ToString();
                    item.Cells[2].Value = dt.Rows[i]["quantidade"].ToString();
                    item.Cells[3].Value = dt.Rows[i]["preco"].ToString();
                    item.Cells[4].Value = dt.Rows[i]["total"].ToString();
                    dgvVenda.Rows.Add(item);
                }
            }
            else
            {
                MessageBox.Show("Nenhum pedido localizado com este ID!", "Não localizado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            con.Close();
        }

        private void btnAtualizarPedido_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("UPDATE PedidoJogo SET valor_total = @valor_total WHERE Id = @Id", con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@Id", SqlDbType.Int).Value = Convert.ToInt32(txtLocacao.Text.Trim());
            cmd.Parameters.AddWithValue("@valor_total", SqlDbType.Decimal).Value = Convert.ToDecimal(txtTotalGeral.Text.Trim());
            cmd.ExecuteNonQuery();

            SqlCommand deletar_itens = new SqlCommand("DELETE FROM JogosPedidos WHERE id_pedido = @id_pedido", con);
            deletar_itens.CommandType = CommandType.Text;
            deletar_itens.Parameters.AddWithValue("@id_pedido", SqlDbType.Int).Value = Convert.ToInt32(txtLocacao.Text.Trim());
            deletar_itens.ExecuteNonQuery();

            foreach (DataGridViewRow dr in dgvVenda.Rows)
            {
                SqlCommand cmditens = new SqlCommand("JogosPedidos", con);
                cmditens.CommandType = CommandType.StoredProcedure;
                cmditens.CommandType = CommandType.StoredProcedure;
                cmditens.Parameters.AddWithValue("@id_pedido", SqlDbType.Int).Value = Convert.ToInt32(txtLocacao.Text);
                cmditens.Parameters.AddWithValue("@id_jogo", SqlDbType.Int).Value = Convert.ToInt32(dr.Cells[0].Value);
                cmditens.Parameters.AddWithValue("@quantidade", SqlDbType.Int).Value = Convert.ToInt32(dr.Cells[2].Value);
                cmditens.Parameters.AddWithValue("@preco", SqlDbType.Decimal).Value = Convert.ToDecimal(dr.Cells[3].Value);
                cmditens.Parameters.AddWithValue("@total", SqlDbType.Decimal).Value = Convert.ToDecimal(dr.Cells[4].Value);
                cmditens.ExecuteNonQuery();
            }
            MessageBox.Show("Pedido atualizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            con.Close();
            dgvVenda.Columns.Clear();
            dgvVenda.Rows.Clear();
            txtLocacao.Text = "";
            con.Close();
        }

        private void btnLocar_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("InserirVendaJogo", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id_pedido", SqlDbType.Int).Value = Convert.ToInt32(txtLocacao.Text);
            cmd.Parameters.AddWithValue("@id_cliente", SqlDbType.NChar).Value = cbxCliente.SelectedValue;
            cmd.Parameters.AddWithValue("@valor_total", SqlDbType.Decimal).Value = Convert.ToDecimal(txtTotalGeral.Text);
            cmd.Parameters.AddWithValue("@data_venda", SqlDbType.Date).Value = DateTime.Now.Date;
            cmd.ExecuteNonQuery();
            foreach (DataGridViewRow dr in dgvVenda.Rows)
            {
                SqlCommand cmditens = new SqlCommand("ItensVendidosJogo", con);
                cmditens.CommandType = CommandType.StoredProcedure;
                cmditens.Parameters.AddWithValue("@id_pedido", SqlDbType.Int).Value = Convert.ToInt32(txtLocacao.Text);
                cmditens.Parameters.AddWithValue("@id_jogo", SqlDbType.Int).Value = Convert.ToInt32(dr.Cells[0].Value);
                cmditens.Parameters.AddWithValue("@quantidade", SqlDbType.Int).Value = Convert.ToInt32(dr.Cells[2].Value);
                cmditens.Parameters.AddWithValue("@preco", SqlDbType.Decimal).Value = Convert.ToDecimal(dr.Cells[3].Value);
                cmditens.Parameters.AddWithValue("@total", SqlDbType.Decimal).Value = Convert.ToDecimal(dr.Cells[4].Value);
                cmditens.ExecuteNonQuery();
            }
            SqlCommand upped = new SqlCommand("UPDATE PedidoJogo SET situacao = 'Locado' WHERE Id = @Id", con);
            upped.CommandType = CommandType.Text;
            upped.Parameters.AddWithValue("@Id", SqlDbType.Int).Value = Convert.ToInt32(txtLocacao.Text);
            upped.ExecuteNonQuery();
            con.Close();
            dgvVenda.Rows.Clear();
            dgvVenda.Refresh();
            txtTotalGeral.Text = "";
            txtLocacao.Text = "";
            txtPreco.Text = "";
            txtQuantidade.Text = "";
            txtIdJogo.Text = "";
            cbxCliente.Text = "";
            cbxJogo.Text = "";
            MessageBox.Show("Venda realizada com sucesso!", "Venda", MessageBoxButtons.OK, MessageBoxIcon.Information);
            con.Close();
        }

        private void btnLocalizarID_Click(object sender, EventArgs e)
        {
            BuscaJogo ped = new BuscaJogo();
            List<BuscaJogo> pedidos = ped.listabuscajogo();
            dgvId.DataSource = pedidos;
        }

        private void btnDevolver_Click(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
